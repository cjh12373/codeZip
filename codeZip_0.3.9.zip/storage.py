import ray
import hdfs
import pymongo
from utils import adjust_the_output_to_json
from bson.objectid import ObjectId
import json
from base_exception import storgeException
import time
import pandas as pd
from io import StringIO

import networkx as nx
import numpy as np



class HDFS():
    def __init__(self, url="http://10.105.222.241:9870"):
        self.client = hdfs.Client(url)
    def wait_and_save_in_hdfs_node(self, key, node, output_ref, name):
        user_id, expId = key.split('-')
        output = {}
        output["status"] = output_ref["status"]
        # 节点执行时间
        output["time"] = output_ref["time"]
        if output_ref["status"] == "error":
            output["node_output"] = ""
        else:
            output["node_output"] = ','.join(
                [adjust_the_output_to_json(item) for item in ray.get(output_ref["node_outputs"])])
        try:
            with self.client.write("/bdap/students/{}/.raytmp/{}/{}.json".format(user_id, expId, node), encoding='UTF8',
                                   overwrite=True) as writer:
                # 关于最终结果的保存格式问题，是将"保存为\"还是直接保存
                writer.write(json.dumps(output))
        except:
            output_ref["status"] = "error"
            output["node_output"] = ""
            raise storgeException("/bdap/students/{}/.raytmp/{}/{}.json".format(user_id, expId, node), name)

    def wait_and_save_in_hdfs(self, key, output_refs):
        user_id, title = key.split('-')
        outputs = {}
        while len(output_refs) > 0:
            ready_ref_lt, _ = ray.wait(list(output_refs.values()))
            ready_ref = ready_ref_lt[0]
            for k, v in output_refs.items():
                if v == ready_ref:
                    output = ','.join([adjust_the_output_to_json(item) for item in ray.get(v)])
                    with self.client.write("/raytmp/{}/{}/{}.json".format(user_id, title, k), encoding='UTF8',
                                           overwrite=True) as writer:
                        writer.write(output)
                    output_refs.pop(k)
                    outputs[k] = output
                    break
        return outputs

    def load_file_from_hdfs(self, path):
        with self.client.read(path) as fs:
            content = fs.read()

    def load_cora_from_hdfs(self, nodePath, edgePath):
        with self.client.read(edgePath) as fs:
            cites = fs.read()
        cites = str(cites, "utf-8")
        cora_cites = pd.read_csv(StringIO(cites), sep='\t', header=None)
        with self.client.read(nodePath) as fs:
            content = fs.read()
        content = str(content, "utf-8")
        cora_content = pd.read_csv(StringIO(content), sep='\t', header=None)
        return cora_content, cora_cites

class Mongo():
    def __init__(self, url="mongodb://bdapadmin:bdapadmin@bdap-cluster-01:27017/bdap_info?maxPoolSize=256"):
        self.client = pymongo.MongoClient(url)

    def fetch_job_info(self, user_id, exp_id):
        ray_collection = self.client.get_database("bdap_info").get_collection("experiment")
        job_info = ray_collection.find_one({'userId': user_id, '_id': ObjectId(exp_id), 'serviceType': 'graph'})
        if job_info is None:
            raise ValueError("Work flow does not exists.")
        return job_info



# def test1():
#     hdfs = HDFS()
#     cora_content, cora_cites = hdfs.load_cora_from_hdfs('/bdap/students/cjh12373/cora/cora.content', '/bdap/students/cjh12373/cora/cora.cites')
#     print(cora_content,cora_cites)
#     # 根据cora生成网络
#     G = nx.Graph()
#     G.add_nodes_from(np.array(cora_content[0]))
#     G.add_edges_from(np.array(cora_cites))
#     # assert nx.is_connected(
#     #     G), "The graph is not connected, and it is recommended to use the maximum connectivity component for preprocessing."
#     print(nx.diameter(G))
#
# test1()



