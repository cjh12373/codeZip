# coding=utf-8
import sys
import ray
from graph_generation import *
from graph_processing import *
from storage import fetch_job_info, wait_and_save_in_hdfs,wait_and_save_in_hdfs_node
from safety import topological_sort, validate_type
import json


def rearrange_job_info_format(job_info):
    new_job_info = {}
    for node in job_info['nodes']:
        if node['group'] == 'graphVisualization':
            continue
        t = new_job_info[node['mark']] = {}
        t['name'] = node['name']
        t['args'] = {}
        for attribute in node['simpleAttributes']:
            t['args'][attribute['name']] = attribute['value']
        t['locators'] = {}
        for anchor in node['inputAnchors']:
            t['locators'][anchor['seq']] = (anchor['sourceAnchor']['nodeMark'], anchor['sourceAnchor']['seq'])
    return new_job_info


def main():
    assert len(sys.argv) == 2, "There is no command line args for execution_engine.py"
    key = sys.argv[1]
    userId,expId=key.split('-')
    job_info=fetch_job_info(userId,expId)

    # define a sequence of execution
    toposorted = topological_sort(job_info)
    print("Passed topological sort")

    # Validate the connected nodes
    validate_type(job_info)
    print("Passed type check")

    new_job_info = rearrange_job_info_format(job_info)

    # Topological sort ensured that the prerequisites are satisfied
    output_refs = dict()
    for node in toposorted:
        output_ref = {"status": "PENDING"}
        name, args, locators = new_job_info[node]['name'],  new_job_info[node]['args'], new_job_info[node]['locators']
        output_ref["node_outputs"] = eval("{}".format(name)).remote(args, output_refs, locators)
        try:
            ray.get(output_ref["node_outputs"])
            output_ref["status"] = "SUCCEEDED"
        except:
            output_ref["status"]="ERROR"
        # 获取已运行节点的执行信息，若发生错误则更新status
        assert wait_and_save_in_hdfs_node(key, node, output_ref), "结果保存出现问题"

        output_refs[node] = output_ref["node_outputs"]

    # print(wait_and_save_in_hdfs(userId+'-'+job_info['title'], output_refs))


if __name__ == "__main__":
    main()
