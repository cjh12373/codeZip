import ray
import hdfs
import pymongo
from utils import adjust_the_output_to_json
from bson.objectid import ObjectId
import json


def fetch_job_info(user_id, exp_id):
    mongo_client = pymongo.MongoClient("mongodb://bdapadmin:bdapadmin@bdap-cluster-01:27017/bdap_info?maxPoolSize=256")
    ray_collection = mongo_client.get_database("bdap_info").get_collection("experiment")
    job_info = ray_collection.find_one({'userId': user_id, '_id': ObjectId(exp_id), 'serviceType': 'graph'})
    if job_info is None:
        raise ValueError("Work flow does not exists.")
    return job_info


def wait_and_save_in_hdfs(key, output_refs):
    hdfs_client = hdfs.Client("http://10.105.222.241:9870")
    user_id, title = key.split('-')
    outputs = {}
    while len(output_refs) > 0:
        ready_ref_lt, _ = ray.wait(list(output_refs.values()))
        ready_ref = ready_ref_lt[0]
        for k, v in output_refs.items():
            if v == ready_ref:
                output = ','.join([adjust_the_output_to_json(item) for item in ray.get(v)])
                with hdfs_client.write("/raytmp/{}/{}/{}.json".format(user_id, title, k), encoding='UTF8', overwrite=True) as writer:
                    writer.write(output)
                output_refs.pop(k)
                outputs[k] = output
                break
    return outputs

def wait_and_save_in_hdfs_node(key, node, output_ref):
    hdfs_client = hdfs.Client("http://10.105.222.241:9870")
    user_id, expId = key.split('-')
    output={}
    state = True
    output["status"]=output_ref["status"]
    if output_ref["status"] == "error":
        output["node_output"]=""
        state=False
    else:
        output["node_output"] = ','.join([adjust_the_output_to_json(item) for item in ray.get(output_ref["node_outputs"])])
    with hdfs_client.write("/bdap/students/{}/.raytmp/{}/{}.json".format(user_id, expId, node), encoding='UTF8',
                           overwrite=True) as writer:
        #关于最终结果的保存格式问题，是将"保存为\"还是直接保存
        writer.write(json.dumps(output))
    assert state, "工作流执行中工作节点运行出现错误"
    return state
