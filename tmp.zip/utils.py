import networkx as nx
from enum import Enum
from typing import List, Dict


class Type(Enum):
    GRAPH = nx.Graph
    BOOL = bool
    DICT = Dict
    LIST = List


def make_list(obj):
    if isinstance(obj, list):
        return obj
    elif obj is not None:
        return [obj]
    else:
        return []


def register(input_type=None, output_type=None):
    def foo(f):
        f.input_type = make_list(input_type)
        f.output_type = make_list(output_type)
        return f
    return foo
