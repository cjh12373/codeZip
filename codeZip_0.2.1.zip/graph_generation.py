import random
import ray
import networkx as nx
from utils import register, Type


# 随机图
@register(output_type=Type.GRAPH)
@ray.remote
def gnp_random_graph(args, output_refs, locators):
    assert {'n', 'p', 'directed'} <= args.keys(), "Missing arguments for RandomGraphGeneration"
    n, p, directed = args['n'], args['p'], args['directed']
    return (nx.gnp_random_graph(n, p, directed=directed),)

#
# # 快速随机图（p很小时生成更快），适用于稀疏图
# @register(output_type=Type.GRAPH)
# @ray.remote
# def gnp_random_sparse_graph(args, output_refs, locators):
#     assert {'n', 'p', 'directed'} <= args.keys(), "Missing arguments for RandomGraphGeneration"
#     n, p, directed = args['n'], args['p'], args['directed']
#     return (nx.fast_gnp_random_graph(n, p, directed=directed),)
#
#
# # 指定结点数和边数的随机图
# @register(output_type=Type.GRAPH)
# @ray.remote
# def gnm_random_graph(args, output_refs, locators):
#     assert {'n', 'm', 'directed'} <= args.keys(), "Missing arguments for RandomGraphGeneration"
#     n, m, directed = args['n'], args['m'], args['directed']
#     return (nx.gnm_random_graph(n, m, directed=directed),)
#
#
# # 快速随机图，适用于稠密图
# @register(output_type=Type.GRAPH)
# @ray.remote
# def gnm_random_dense_graph(args, output_refs, locators):
#     assert 'n' in args and 'm' in args, "Missing arguments for RandomGraphGeneration"
#     n, m = args['n'], args['m']
#     return (nx.dense_gnm_random_graph(n, m),)
#
#
# # 星型网络
# @register(output_type=Type.GRAPH)
# @ray.remote
# def star_graph(args, output_refs, locators):
#     assert 'n' in args, "Missing arguments for StarGraphGeneration"
#     n = args['n']
#     return (nx.star_graph(n),)
#
#
# # 最近邻耦合网络
# @register(output_type=Type.UN_GRAPH)
# @ray.remote
# def nearest_neighbor_coupling_graph(args, output_refs, locators):
#     assert 'n' in args and 'k' in args, "Missing arguments for NNCGraphGeneration"
#     n, k = args['n'], args['k']
#     half_k = k // 2
#     NNC_net = nx.Graph()
#     NNC_net.add_nodes_from(range(n))
#     NNC_net.add_edges_from([(i, j % n) for i in range(n) for j in range(i - half_k, i + half_k + 1) if j != i])
#     return (NNC_net,)
#
#
# # 全局耦合网络（完全图）
# @register(output_type=Type.GRAPH)
# @ray.remote
# def complete_graph(args, output_refs, locators):
#     assert 'n' in args, "Missing arguments for CompleteGraphGeneration"
#     n = args['n']
#     return (nx.complete_graph(n),)
#
#
# global_coupling_network = complete_graph
#
#
# # 无标度网络
# @register(output_type=Type.GRAPH)
# @ray.remote
# def barabasi_albert_graph(args, output_refs, locators):
#     assert 'n' in args and 'm' in args, "Missing arguments for BAGraphGeneration"
#     n, m = args['n'], args['m']
#     return (nx.barabasi_albert_graph(n, m),)
#
#
# scale_free_network = barabasi_albert_graph
#
#
# # 小世界网络
# @register(output_type=Type.GRAPH)
# @ray.remote
# def watts_strogatz_graph(args, output_refs, locators):
#     assert {'n', 'k', 'p'} <= args.keys(), "Missing arguments for SWGraphGeneration"
#     n, k, p = args['n'], args['k'], args['p']
#     return (nx.watts_strogatz_graph(n, k, p),)
#
#
# small_world_network = watts_strogatz_graph
#
#
# # 随机权重网络 np
# @register(output_type=Type.GRAPH)
# @ray.remote
# def gnp_random_weighted_graph(args, output_refs, locators):
#     assert {'n', 'p', 'directed'} <= args.keys(), "Missing arguments for RandomWeightedGraphGeneration"
#     n, p, directed = args['n'], args['p'], args['directed']
#     if {'a', 'b'} <= args.keys():
#         a, b = args['a'], args['b']
#     else:
#         a, b = 0, 1
#     G = nx.gnp_random_graph(n, p, directed=directed)
#     for (u, v, d) in G.edges(data=True):
#         d['weight'] = random.uniform(a, b)
#     return (G,)
#
#
# # 随机权重网络 nm
# @register(output_type=Type.GRAPH)
# @ray.remote
# def gnm_random_weighted_graph(args, output_refs, locators):
#     assert {'n', 'm', 'directed'} <= args.keys(), "Missing arguments for RandomWeightedGraphGeneration"
#     n, m, directed = args['n'], args['m'], args['directed']
#     if {'a', 'b'} <= args.keys():
#         a, b = args['a'], args['b']
#     else:
#         a, b = 0, 1
#     G = nx.gnm_random_graph(n, m, directed=directed)
#     for (u, v, d) in G.edges(data=True):
#         d['weight'] = random.uniform(a, b)
#     return (G,)

@register(output_type=Type.GRAPH)
@ray.remote
def smallWorldNetwork(args, output_refs, locators):
    assert {'vertex', 'K', 'p'} <= args.keys(), "Missing arguments for SWGraphGeneration"
    n, k, p = int(args['vertex']), int(args['K']), float(args['p'])
    print(n,k,p)
    return (nx.watts_strogatz_graph(n, k, p),)