import json
from typing import Dict, List, Set, Tuple, Union, Generator, Iterator
import networkx as nx
from enum import Enum
import ray


class Type(Enum):
    GRAPH = Union[nx.Graph, nx.DiGraph]
    UN_GRAPH = nx.Graph
    DI_GRAPH = nx.DiGraph
    BOOL = bool
    INT = int
    FLOAT = float
    DICT = Dict
    LIST = List
    SET = Set
    TUPLE = Tuple
    GENERATOR = Generator
    ITERATOR = Iterator


def isDisplay(type):
    #此处保存的为可视化组件，不参与运算
    displayType=['graphShow']
    if(displayType.count(type)==0):
        return False
    return True


def make_list(obj):
    if isinstance(obj, list):
        return obj
    elif obj is not None:
        return [obj]
    else:
        return []


def register(input_type=None, output_type=None):
    def foo(f):
        f.input_type = make_list(input_type)
        f.output_type = make_list(output_type)
        return f

    return foo


def nxgraph2json(graph: Type.GRAPH):
    nodes, edges = graph.nodes, graph.edges
    data = {
        "node_number": len(nodes),
        "edge_number": len(edges),
        "nodes": [n for n in nodes],
        "edges": [e for e in edges]
    }
    return json.dumps(data, ensure_ascii=False)


special_types = {
    nx.Graph: nxgraph2json,
    nx.DiGraph: nxgraph2json
}


def adjust_the_output_to_json(output):
    if type(output) in special_types:
        return special_types[type(output)](output)
    return json.dumps(output, ensure_ascii=False)


def fetch(output_refs, locator):
    return ray.get(output_refs[locator[0]])[locator[1]]
